const iconClickHandler = (evt) => {
    evt.preventDefault();

    let srt = 'laravel mix settings';

    alert(srt);
};

export default iconClickHandler;
